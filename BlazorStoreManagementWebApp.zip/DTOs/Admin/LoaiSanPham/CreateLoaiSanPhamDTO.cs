﻿namespace BlazorStoreManagementWebApp.DTOs.Admin.LoaiSanPham
{
    public class CreateLoaiSanPhamDTO
    {
    }
}
