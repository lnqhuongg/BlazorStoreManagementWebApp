﻿namespace BlazorStoreManagementWebApp.DTOs.Client.DonHang
{
    public class CreateDonHangDTO
    {
    }
}
