﻿namespace BlazorStoreManagementWebApp.Models.Entities
{
    public class LoaiSanPham
    {
    }
}
